"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";

/* =========================
   🔹 숫자 유틸
========================= */

const formatNumber = (value: number | "") => {
  if (value === "" || isNaN(Number(value))) return "";
  return Number(value).toLocaleString();
};

const parseNumber = (value: string) => {
  return value.replace(/,/g, "");
};

/* =========================
   🔹 InputField (콤마 포함)
========================= */

interface InputFieldProps {
  label: string;
  value: number | "";
  onChange: (value: number | "") => void;
  placeholder?: string;
}

export function InputField({
  label,
  value,
  onChange,
  placeholder,
}: InputFieldProps) {
  const [displayValue, setDisplayValue] = useState("");

  useEffect(() => {
    setDisplayValue(formatNumber(value));
  }, [value]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = parseNumber(e.target.value);

    if (raw === "") {
      onChange("");
      setDisplayValue("");
      return;
    }

    const num = Number(raw);
    if (!isNaN(num)) {
      onChange(num);
      setDisplayValue(formatNumber(num));
    }
  };

  return (
    <div className="flex flex-col gap-2">
      <label className="text-sm font-semibold text-slate-700">{label}</label>
      <input
        type="text"
        value={displayValue}
        onChange={handleChange}
        placeholder={placeholder}
        className="w-full rounded-xl border border-slate-200 px-4 py-3 text-lg focus:outline-none focus:ring-2 focus:ring-slate-300"
      />
    </div>
  );
}

/* =========================
   🔹 공통 UI
========================= */

export function PageHeader({ title }: { title: string }) {
  return (
    <h1 className="text-3xl font-bold tracking-tight text-slate-900 mb-8">
      {title}
    </h1>
  );
}

export function SectionCard({ children }: { children: React.ReactNode }) {
  return (
    <section className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm mb-10">
      {children}
    </section>
  );
}

export function Article({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) {
  return (
    <div className="mb-6">
      <h2 className="text-lg font-bold mb-2">{title}</h2>
      <div className="text-sm text-slate-600 leading-relaxed">{children}</div>
    </div>
  );
}

/* =========================
   🔹 FAQ
========================= */

export function FaqSection({ children }: { children: React.ReactNode }) {
  return <div className="mt-10">{children}</div>;
}

export function FaqItem({
  question,
  answer,
}: {
  question: string;
  answer: string;
}) {
  return (
    <div className="mb-4">
      <p className="font-semibold">{question}</p>
      <p className="text-sm text-slate-600">{answer}</p>
    </div>
  );
}

/* =========================
   🔹 관련 계산기
========================= */

export function RelatedCalculators({
  links,
}: {
  links: { href: string; title: string; desc: string }[];
}) {
  return (
    <section className="mt-12">
      <h2 className="mb-4 text-lg font-bold text-slate-900">관련 계산기</h2>
      <div className="grid gap-4 sm:grid-cols-2">
        {links.map((item) => (
          <Link
            key={item.href}
            href={item.href}
            className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm transition hover:border-slate-300 hover:shadow-md"
          >
            <h3 className="font-semibold text-slate-900">{item.title}</h3>
            <p className="mt-2 text-sm leading-relaxed text-slate-600">
              {item.desc}
            </p>
          </Link>
        ))}
      </div>
    </section>
  );
}

/* =========================
   🔥 Disclaimer (근본 추가)
========================= */

export function Disclaimer() {
  return (
    <section className="mt-12 rounded-2xl border border-slate-200 bg-white p-6 text-sm leading-relaxed text-slate-600 shadow-sm">
      <p>
        본 사이트에서 제공하는 계산 결과는 참고용이며, 투자 권유를 의미하지 않습니다.
        투자에 대한 최종 판단과 책임은 사용자 본인에게 있습니다.
      </p>
    </section>
  );
}